import { useState, useEffect, createContext, useContext, useCallback } from "react";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";

const EDGE_URL = "https://tcvpkupkasvptdivfwmo.supabase.co/functions/v1/server";

async function callEdge(action: string, payload: Record<string, unknown>) {
  const res = await fetch(EDGE_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRjdnBrdXBrYXN2cHRkaXZmd21vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM2NTcxNTcsImV4cCI6MjA5OTIzMzE1N30.rhU-0JganIbQDPvFGuICtLv4ADAhME3I48cOG03j_P8" },
    body: JSON.stringify({ action, payload }),
  });
  return res.json();
}
import {
  LayoutDashboard, Server, Globe, Mail, Send, Users, FileText,
  ShieldCheck, ScrollText, Settings, HardDrive, Share2, LogOut,
  RefreshCw, Plus, CheckCircle, XCircle, Clock, Activity, Zap, Eye,
  AlertTriangle, TrendingUp, BarChart2, Trash2, Edit2, Copy, Search,
  Upload, Download, X, Lock, User, Shield, UserPlus, KeyRound,
  ChevronRight, Bell, Moon, Sun, ToggleLeft,
} from "lucide-react";

// ─── Auth Context ─────────────────────────────────────────────────────────────

type AuthUser = {
  id: string;
  email: string;
  role: "admin" | "user";
  name: string;
};

type AuthCtx = {
  user: AuthUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<string | null>;
  signup: (email: string, password: string, name: string) => Promise<string | null>;
  logout: () => void;
};

const AuthContext = createContext<AuthCtx>({
  user: null, loading: true,
  login: async () => null,
  signup: async () => null,
  logout: () => {},
});

const useAuth = () => useContext(AuthContext);

// Demo accounts (used when Supabase is not configured)
const DEMO_USERS: (AuthUser & { password: string })[] = [
  { id: "1", email: "admin@bosssender.com", password: "admin123", role: "admin", name: "Admin User" },
  { id: "2", email: "user@bosssender.com", password: "user123", role: "user", name: "Demo User" },
];

const SESSION_KEY = "bosssender_session";

function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isSupabaseConfigured && supabase) {
      supabase.auth.getSession().then(({ data }) => {
        if (data.session?.user) {
          const u = data.session.user;
          setUser({ id: u.id, email: u.email!, role: (u.user_metadata?.role as any) || "user", name: u.user_metadata?.name || u.email! });
        }
        setLoading(false);
      });
      const { data: { subscription } } = supabase.auth.onAuthStateChange((_ev, session) => {
        if (session?.user) {
          const u = session.user;
          setUser({ id: u.id, email: u.email!, role: (u.user_metadata?.role as any) || "user", name: u.user_metadata?.name || u.email! });
        } else {
          setUser(null);
        }
      });
      return () => subscription.unsubscribe();
    } else {
      // localStorage fallback
      const stored = localStorage.getItem(SESSION_KEY);
      if (stored) setUser(JSON.parse(stored));
      setLoading(false);
    }
  }, []);

  const login = useCallback(async (email: string, password: string): Promise<string | null> => {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      return error ? error.message : null;
    }
    const found = DEMO_USERS.find((u) => u.email === email && u.password === password);
    if (!found) return "Invalid email or password";
    const { password: _p, ...rest } = found;
    setUser(rest);
    localStorage.setItem(SESSION_KEY, JSON.stringify(rest));
    return null;
  }, []);

  const signup = useCallback(async (email: string, password: string, name: string): Promise<string | null> => {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.auth.signUp({ email, password, options: { data: { name, role: "user" } } });
      return error ? error.message : null;
    }
    if (DEMO_USERS.find((u) => u.email === email)) return "Email already registered";
    const newUser: AuthUser = { id: Date.now().toString(), email, role: "user", name };
    DEMO_USERS.push({ ...newUser, password });
    setUser(newUser);
    localStorage.setItem(SESSION_KEY, JSON.stringify(newUser));
    return null;
  }, []);

  const logout = useCallback(() => {
    if (isSupabaseConfigured && supabase) supabase.auth.signOut();
    setUser(null);
    localStorage.removeItem(SESSION_KEY);
  }, []);

  return <AuthContext.Provider value={{ user, loading, login, signup, logout }}>{children}</AuthContext.Provider>;
}

// ─── Auth Pages ───────────────────────────────────────────────────────────────

function AuthPage() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const { login, signup } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setSuccess("");
    if (!email || !password) { setError("Please fill all fields"); return; }
    if (mode === "signup" && !name) { setError("Please enter your name"); return; }
    setLoading(true);
    const err = mode === "login"
      ? await login(email, password)
      : await signup(email, password, name);
    setLoading(false);
    if (err) setError(err);
    else if (mode === "signup") setSuccess("Account created! You can now log in.");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Background glow */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-violet-600/10 blur-3xl" />
      </div>

      <div className="w-full max-w-md relative">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-700 shadow-2xl shadow-purple-900/50 mb-4">
            <Send size={24} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Boss Sender</h1>
          <p className="text-sm text-muted-foreground mt-1">Email Marketing Pro</p>
        </div>

        {/* Card */}
        <div className="bg-card border border-border rounded-2xl p-8 shadow-2xl">
          {/* Tabs */}
          <div className="flex gap-1 p-1 bg-muted rounded-xl mb-6">
            {(["login", "signup"] as const).map((m) => (
              <button
                key={m}
                onClick={() => { setMode(m); setError(""); setSuccess(""); }}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${mode === m ? "bg-primary text-white shadow-md" : "text-muted-foreground hover:text-foreground"}`}
              >
                {m === "login" ? "Sign In" : "Sign Up"}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "signup" && (
              <div>
                <label className="text-xs font-medium text-muted-foreground block mb-1.5">Full Name</label>
                <div className="relative">
                  <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    value={name} onChange={(e) => setName(e.target.value)}
                    placeholder="Your full name"
                    className="w-full bg-input-background border border-border rounded-lg pl-9 pr-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1.5">Email Address</label>
              <div className="relative">
                <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full bg-input-background border border-border rounded-lg pl-9 pr-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1.5">Password</label>
              <div className="relative">
                <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-input-background border border-border rounded-lg pl-9 pr-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs">
                <XCircle size={13} /> {error}
              </div>
            )}
            {success && (
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs">
                <CheckCircle size={13} /> {success}
              </div>
            )}

            <button
              type="submit" disabled={loading}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-700 text-white text-sm font-semibold hover:opacity-90 disabled:opacity-60 transition-all shadow-lg shadow-purple-900/40 flex items-center justify-center gap-2"
            >
              {loading && <RefreshCw size={14} className="animate-spin" />}
              {mode === "login" ? "Sign In" : "Create Account"}
            </button>
          </form>

          {/* Demo hint */}
          {!isSupabaseConfigured && (
            <div className="mt-5 p-3 rounded-xl bg-violet-500/10 border border-violet-500/20">
              <p className="text-xs text-violet-300 font-medium mb-1.5">Demo Credentials</p>
              <div className="space-y-1 text-[11px] text-muted-foreground">
                <div className="flex justify-between"><span>Admin:</span><span className="font-mono">admin@bosssender.com / admin123</span></div>
                <div className="flex justify-between"><span>User:</span><span className="font-mono">user@bosssender.com / user123</span></div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Types ────────────────────────────────────────────────────────────────────

type Page =
  | "dashboard" | "smtp" | "proxies" | "single-mail" | "bulk-mails"
  | "recipients" | "templates" | "email-verifier" | "logs" | "settings"
  | "backup" | "admin-settings" | "resource-sharing" | "admin-users";

// ─── Sidebar ──────────────────────────────────────────────────────────────────

const navItems: { id: Page; label: string; icon: React.ElementType }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "smtp", label: "SMTP Accounts", icon: Server },
  { id: "proxies", label: "Proxies", icon: Globe },
  { id: "single-mail", label: "Single Mail", icon: Mail },
  { id: "bulk-mails", label: "Bulk Mails Sender", icon: Send },
  { id: "recipients", label: "Recipients", icon: Users },
  { id: "templates", label: "Templates", icon: FileText },
  { id: "email-verifier", label: "Email Verifier", icon: ShieldCheck },
  { id: "logs", label: "Logs", icon: ScrollText },
  { id: "settings", label: "Settings", icon: Settings },
];

const adminItems: { id: Page; label: string; icon: React.ElementType }[] = [
  { id: "admin-users", label: "User Management", icon: Users },
  { id: "backup", label: "Backup & Restore", icon: HardDrive },
  { id: "admin-settings", label: "Admin Settings", icon: Shield },
  { id: "resource-sharing", label: "Resource Sharing", icon: Share2 },
];

function Sidebar({ page, setPage }: { page: Page; setPage: (p: Page) => void }) {
  const { user, logout } = useAuth();

  return (
    <aside className="w-56 shrink-0 flex flex-col h-screen bg-sidebar border-r border-sidebar-border">
      <div className="flex items-center gap-3 px-4 py-5 border-b border-sidebar-border">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center shadow-lg shadow-purple-900/40">
          <Send size={16} className="text-white" />
        </div>
        <div>
          <div className="text-white font-semibold text-sm leading-tight">Boss Sender</div>
          <div className="text-muted-foreground text-[10px]">Email Marketing Pro</div>
        </div>
      </div>

      <nav className="flex-1 px-2 py-3 overflow-y-auto space-y-0.5">
        {navItems.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setPage(id)}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all ${page === id ? "bg-primary text-white font-medium shadow-md shadow-purple-900/40" : "text-muted-foreground hover:text-foreground hover:bg-sidebar-accent"}`}
          >
            <Icon size={15} />{label}
          </button>
        ))}

        {user?.role === "admin" && (
          <div className="pt-3">
            <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground px-3 mb-1">Admin Only</div>
            {adminItems.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setPage(id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all ${page === id ? "bg-primary text-white font-medium" : "text-muted-foreground hover:text-foreground hover:bg-sidebar-accent"}`}
              >
                <Icon size={15} />{label}
              </button>
            ))}
          </div>
        )}
      </nav>

      <div className="px-3 pb-4 space-y-2 border-t border-sidebar-border pt-3">
        <div className="flex items-center gap-2 px-2">
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-400 to-purple-600 flex items-center justify-center text-white text-xs font-bold shrink-0">
            {user?.name?.[0]?.toUpperCase() || "U"}
          </div>
          <div className="min-w-0">
            <div className="text-xs font-medium text-foreground truncate">{user?.name}</div>
            <div className="text-[10px] text-muted-foreground capitalize">{user?.role}</div>
          </div>
          {user?.role === "admin" && (
            <Shield size={12} className="text-violet-400 shrink-0 ml-auto" />
          )}
        </div>
        <button onClick={logout}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-red-400 hover:bg-red-500/10 transition-all font-medium"
        >
          <LogOut size={14} /> Logout
        </button>
      </div>
    </aside>
  );
}

// ─── Stat Card ────────────────────────────────────────────────────────────────

function StatCard({ label, value, sub, icon: Icon, iconBg, trend }: {
  label: string; value: string | number; sub?: string;
  icon: React.ElementType; iconBg: string; trend?: string;
}) {
  return (
    <div className="bg-card rounded-xl p-4 border border-border flex flex-col gap-3">
      <div className="flex items-start justify-between">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${iconBg}`}>
          <Icon size={18} className="text-white" />
        </div>
        {trend && <span className="text-xs font-medium text-emerald-400 flex items-center gap-0.5"><TrendingUp size={11} /> {trend}</span>}
      </div>
      <div>
        <div className="text-2xl font-semibold text-foreground">{value}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
        {sub && <div className="text-[10px] text-muted-foreground">{sub}</div>}
      </div>
    </div>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

function Dashboard({ setPage }: { setPage: (p: Page) => void }) {
  const { user } = useAuth();
  const activity = [
    { msg: "Activity logged", time: "10:47:01 PM" }, { msg: "Activity logged", time: "10:42:01 PM" },
    { msg: "Activity logged", time: "8:16:21 PM" }, { msg: "Activity logged", time: "8:18:10 PM" },
    { msg: "Activity logged", time: "8:13:02 PM" }, { msg: "Activity logged", time: "7:49:02 PM" },
  ];
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-foreground flex items-center gap-2">
            <BarChart2 size={22} className="text-primary" /> Boss Sender Dashboard
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Welcome back, <span className="text-foreground font-medium">{user?.name}</span> — Monitor and control your email campaigns in real-time
          </p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all">
            <RefreshCw size={14} /> Refresh
          </button>
          <button onClick={() => setPage("bulk-mails")} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all shadow-md shadow-purple-900/40">
            <Plus size={14} /> New Campaign
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Campaigns" value={0} sub="Active & completed" icon={Send} iconBg="bg-violet-600" trend="+12%" />
        <StatCard label="Emails Sent" value={0} sub="Sent today" icon={Mail} iconBg="bg-cyan-600" trend="+24%" />
        <StatCard label="SMTP Accounts" value="29/29" sub="Healthy connections" icon={Server} iconBg="bg-emerald-600" />
        <StatCard label="Success Rate" value="0%" sub="Overall delivery rate" icon={TrendingUp} iconBg="bg-amber-600" />
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Pending" value={0} sub="Queued messages" icon={Clock} iconBg="bg-orange-500" />
        <StatCard label="Failed" value={0} sub="Bounced / errored" icon={XCircle} iconBg="bg-red-600" />
        <StatCard label="Send Rate" value="0/min" sub="Avg send speed" icon={Zap} iconBg="bg-pink-600" />
        <StatCard label="Open Rate" value="0%" sub="Recipient opens" icon={Eye} iconBg="bg-indigo-600" />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Send Single Email", sub: "Send to one recipient", icon: Mail, color: "from-violet-600 to-purple-700", page: "single-mail" as Page },
          { label: "Verify Emails", sub: "Check email validity", icon: ShieldCheck, color: "from-cyan-600 to-blue-700", page: "email-verifier" as Page },
          { label: "Email Templates", sub: "Manage templates", icon: FileText, color: "from-emerald-600 to-teal-700", page: "templates" as Page },
          { label: "View Logs", sub: "Monitor activity", icon: ScrollText, color: "from-amber-600 to-orange-700", page: "logs" as Page },
        ].map(({ label, sub, icon: Icon, color, page }) => (
          <button key={label} onClick={() => setPage(page)}
            className={`flex flex-col items-start gap-3 p-4 rounded-xl bg-gradient-to-br ${color} hover:opacity-90 transition-all shadow-lg text-white text-left`}
          >
            <Icon size={20} />
            <div><div className="text-sm font-semibold">{label}</div><div className="text-xs opacity-80">{sub}</div></div>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-foreground">SMTP Status</h3>
            <span className="text-xs text-emerald-400 flex items-center gap-1"><CheckCircle size={11} /> All Active</span>
          </div>
          <div className="space-y-2">
            {["secure.emailsrvr.com", "secure.emailsrvr.com"].map((host, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-400" /><span className="text-xs text-foreground">{host}</span></div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-medium">Active</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-2 mb-3">
            <Activity size={14} className="text-primary" />
            <h3 className="text-sm font-semibold text-foreground">Recent Activity</h3>
          </div>
          <div className="space-y-0">
            {activity.map((a, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center"><Activity size={10} className="text-muted-foreground" /></div>
                  <span className="text-xs text-foreground">{a.msg}</span>
                </div>
                <span className="text-[10px] text-muted-foreground">{a.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── SMTP Accounts ────────────────────────────────────────────────────────────

type SmtpAccount = {
  id: number; name: string; host: string; port: number;
  fromEmail: string; fromName: string; smtpUser: string; smtpPass: string;
  maxPerHour: number; sentToday: number; active: boolean;
  status: "Unknown" | "Active" | "Failed";
};

const initialSmtpAccounts: SmtpAccount[] = [];

function SmtpAccounts() {
  const [accounts, setAccounts] = useState<SmtpAccount[]>(initialSmtpAccounts);
  const [showAdd, setShowAdd] = useState(false);
  const [verifying, setVerifying] = useState<number | null>(null);
  const [form, setForm] = useState({ name: "", host: "", port: "587", fromEmail: "", fromName: "", smtpUser: "", smtpPass: "" });

  const toggle = (id: number) => setAccounts((p) => p.map((a) => a.id === id ? { ...a, active: !a.active } : a));

  const addAccount = async () => {
    if (!form.host || !form.fromEmail || !form.smtpUser) return;
    const newAcc: SmtpAccount = {
      id: Date.now(), name: form.name || form.host, host: form.host,
      port: Number(form.port) || 587, fromEmail: form.fromEmail,
      fromName: form.fromName, smtpUser: form.smtpUser, smtpPass: form.smtpPass,
      maxPerHour: 100, sentToday: 0, active: true, status: "Unknown",
    };
    setAccounts((p) => [...p, newAcc]);
    setForm({ name: "", host: "", port: "587", fromEmail: "", fromName: "", smtpUser: "", smtpPass: "" });
    setShowAdd(false);
  };

  const verifySmtp = async (acc: SmtpAccount) => {
    setVerifying(acc.id);
    try {
      const res = await callEdge("verify-smtp", { smtpHost: acc.host, smtpPort: acc.port, smtpUser: acc.smtpUser, smtpPass: acc.smtpPass });
      setAccounts((p) => p.map((a) => a.id === acc.id ? { ...a, status: res.success ? "Active" : "Failed" } : a));
    } catch {
      setAccounts((p) => p.map((a) => a.id === acc.id ? { ...a, status: "Failed" } : a));
    }
    setVerifying(null);
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><Server size={20} className="text-primary" /> SMTP Accounts</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Manage your email sending servers</p></div>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all">
          <Plus size={14} /> Add SMTP Account
        </button>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[{ label: "Total Accounts", val: accounts.length, color: "text-foreground" }, { label: "Active", val: accounts.filter((a) => a.active).length, color: "text-emerald-400" }, { label: "Verified", val: accounts.filter((a) => a.status === "Active").length, color: "text-amber-400" }].map(({ label, val, color }) => (
          <div key={label} className="bg-card rounded-xl border border-border p-4 text-center">
            <div className={`text-2xl font-bold ${color}`}>{val}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
          </div>
        ))}
      </div>

      {accounts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-4"><Server size={24} className="text-muted-foreground" /></div>
          <h3 className="text-base font-medium text-foreground mb-1">No SMTP accounts yet</h3>
          <p className="text-xs text-muted-foreground mb-4">Add your first SMTP server to start sending emails</p>
          <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all"><Plus size={14} /> Add SMTP Account</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {accounts.map((acc) => (
            <div key={acc.id} className="bg-card rounded-xl border border-border p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-violet-600/20 flex items-center justify-center"><Server size={14} className="text-violet-400" /></div>
                  <div><div className="text-sm font-medium text-foreground">{acc.name}</div><div className="text-[10px] text-muted-foreground">{acc.host}:{acc.port}</div></div>
                </div>
                <button onClick={() => toggle(acc.id)} className={`relative w-9 h-5 rounded-full transition-colors ${acc.active ? "bg-emerald-500" : "bg-muted"}`}>
                  <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform shadow ${acc.active ? "translate-x-4" : "translate-x-0.5"}`} />
                </button>
              </div>
              <div className="space-y-1 text-xs">
                {[["From Email", acc.fromEmail], ["From Name", acc.fromName || "—"], ["Max/Hour", acc.maxPerHour], ["Sent Today", acc.sentToday]].map(([k, v]) => (
                  <div key={String(k)} className="flex justify-between">
                    <span className="text-muted-foreground">{k}</span>
                    <span className="text-foreground truncate max-w-[140px]">{v}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between pt-1 border-t border-border">
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${acc.status === "Active" ? "bg-emerald-500/20 text-emerald-400" : acc.status === "Failed" ? "bg-red-500/20 text-red-400" : "bg-muted text-muted-foreground"}`}>{acc.status}</span>
                <div className="flex gap-1">
                  <button onClick={() => verifySmtp(acc)} disabled={verifying === acc.id} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-cyan-400 transition-all" title="Test connection">
                    {verifying === acc.id ? <RefreshCw size={12} className="animate-spin" /> : <CheckCircle size={12} />}
                  </button>
                  <button onClick={() => setAccounts((p) => p.filter((a) => a.id !== acc.id))} className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-all"><Trash2 size={12} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showAdd && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-md p-6 space-y-3 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-1"><h2 className="text-base font-semibold text-foreground">Add SMTP Account</h2><button onClick={() => setShowAdd(false)} className="text-muted-foreground hover:text-foreground"><X size={16} /></button></div>
            {([["Account Name", "name", "text", "e.g. Rackspace 1"], ["SMTP Host", "host", "text", "smtp.example.com"], ["Port", "port", "number", "587"], ["From Email", "fromEmail", "email", "you@example.com"], ["From Name", "fromName", "text", "Your Name"], ["SMTP Username", "smtpUser", "text", "SMTP login username"], ["SMTP Password", "smtpPass", "password", "SMTP password"]] as const).map(([label, key, type, ph]) => (
              <div key={key}>
                <label className="text-xs font-medium text-muted-foreground block mb-1">{label}</label>
                <input type={type} placeholder={ph} value={(form as any)[key]} onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                  className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
              </div>
            ))}
            <div className="flex gap-2 pt-2">
              <button onClick={() => setShowAdd(false)} className="flex-1 py-2 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all">Cancel</button>
              <button onClick={addAccount} className="flex-1 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all">Add Account</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Proxies ──────────────────────────────────────────────────────────────────

function Proxies() {
  const [proxies, setProxies] = useState<{ id: number; host: string; port: string; type: string }[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ host: "", port: "", user: "", pass: "", type: "HTTP" });
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><Globe size={20} className="text-primary" /> Proxies</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Manage proxy servers for email routing</p></div>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all"><Plus size={14} /> Add Proxy</button>
      </div>
      {proxies.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-4"><Globe size={28} className="text-muted-foreground" /></div>
          <h3 className="text-base font-medium text-foreground mb-1">No proxies configured</h3>
          <p className="text-xs text-muted-foreground mb-4">Add proxy servers to route your email traffic</p>
          <button onClick={() => setShowAdd(true)} className="px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all">Add Your First Proxy</button>
        </div>
      ) : (
        <div className="space-y-2">
          {proxies.map((p) => (
            <div key={p.id} className="bg-card border border-border rounded-xl px-4 py-3 flex items-center justify-between">
              <span className="text-sm text-foreground">{p.host}:{p.port}</span>
              <div className="flex items-center gap-3"><span className="text-xs text-muted-foreground">{p.type}</span>
                <button onClick={() => setProxies(proxies.filter((x) => x.id !== p.id))} className="text-muted-foreground hover:text-red-400 transition-colors"><Trash2 size={13} /></button></div>
            </div>
          ))}
        </div>
      )}
      {showAdd && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="text-base font-semibold text-foreground">Add Proxy</h2><button onClick={() => setShowAdd(false)} className="text-muted-foreground hover:text-foreground"><X size={16} /></button></div>
            {(["host", "port", "user", "pass"] as const).map((k) => (
              <div key={k}><label className="text-xs font-medium text-muted-foreground block mb-1 capitalize">{k === "user" ? "Username" : k === "pass" ? "Password" : k.charAt(0).toUpperCase() + k.slice(1)}</label>
                <input value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
            ))}
            <div><label className="text-xs font-medium text-muted-foreground block mb-1">Type</label>
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary">
                {["HTTP", "HTTPS", "SOCKS4", "SOCKS5"].map((t) => <option key={t}>{t}</option>)}
              </select></div>
            <div className="flex gap-2">
              <button onClick={() => setShowAdd(false)} className="flex-1 py-2 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all">Cancel</button>
              <button onClick={() => { if (form.host) { setProxies([...proxies, { id: Date.now(), host: form.host, port: form.port, type: form.type }]); setShowAdd(false); } }} className="flex-1 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all">Add</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Single Mail ──────────────────────────────────────────────────────────────

function SingleMail() {
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [htmlBody, setHtmlBody] = useState("");
  const [textBody, setTextBody] = useState("");
  const [smtpHost, setSmtpHost] = useState("");
  const [smtpPort, setSmtpPort] = useState("587");
  const [smtpUser, setSmtpUser] = useState("");
  const [smtpPass, setSmtpPass] = useState("");
  const [fromEmail, setFromEmail] = useState("");
  const [fromName, setFromName] = useState("");
  const [sending, setSending] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; msg: string } | null>(null);

  const sendEmail = async () => {
    if (!to || !subject || !smtpHost || !smtpUser || !fromEmail) {
      setResult({ ok: false, msg: "Please fill in all required fields." });
      return;
    }
    setSending(true);
    setResult(null);
    try {
      const res = await callEdge("send-email", {
        smtpHost, smtpPort, smtpUser, smtpPass,
        fromEmail, fromName, to, subject,
        html: htmlBody || undefined,
        text: textBody || undefined,
      });
      setResult(res.success
        ? { ok: true, msg: `Email sent! Message ID: ${res.messageId}` }
        : { ok: false, msg: res.error || "Failed to send email." });
    } catch (e: any) {
      setResult({ ok: false, msg: e.message || "Network error." });
    }
    setSending(false);
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><Mail size={20} className="text-primary" /> Send Single Email</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Send individual emails instantly with full automation</p></div>

      {result && (
        <div className={`flex items-start gap-2 px-4 py-3 rounded-xl border text-sm ${result.ok ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400" : "bg-red-500/10 border-red-500/30 text-red-400"}`}>
          {result.ok ? <CheckCircle size={16} className="mt-0.5 shrink-0" /> : <XCircle size={16} className="mt-0.5 shrink-0" />}
          {result.msg}
        </div>
      )}

      {/* SMTP Config */}
      <div className="bg-card rounded-xl border border-border p-5 space-y-4">
        <div className="flex items-center gap-2"><Server size={16} className="text-primary" /><h2 className="text-sm font-semibold text-foreground">SMTP Configuration</h2></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div><label className="text-xs font-medium text-muted-foreground block mb-1">SMTP Host *</label>
            <input value={smtpHost} onChange={(e) => setSmtpHost(e.target.value)} placeholder="smtp.example.com" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
          <div><label className="text-xs font-medium text-muted-foreground block mb-1">Port</label>
            <input value={smtpPort} onChange={(e) => setSmtpPort(e.target.value)} placeholder="587" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
          <div><label className="text-xs font-medium text-muted-foreground block mb-1">SMTP Username *</label>
            <input value={smtpUser} onChange={(e) => setSmtpUser(e.target.value)} placeholder="your@email.com" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
          <div><label className="text-xs font-medium text-muted-foreground block mb-1">SMTP Password</label>
            <input type="password" value={smtpPass} onChange={(e) => setSmtpPass(e.target.value)} placeholder="••••••••" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
          <div><label className="text-xs font-medium text-muted-foreground block mb-1">From Email *</label>
            <input value={fromEmail} onChange={(e) => setFromEmail(e.target.value)} placeholder="sender@example.com" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
          <div><label className="text-xs font-medium text-muted-foreground block mb-1">From Name</label>
            <input value={fromName} onChange={(e) => setFromName(e.target.value)} placeholder="Your Name" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
        </div>
      </div>

      {/* Email Details */}
      <div className="bg-card rounded-xl border border-border p-5 space-y-4">
        <h2 className="text-sm font-semibold text-foreground">Email Details</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div><label className="text-xs font-medium text-muted-foreground block mb-1">Recipient Email(s) *</label>
            <input value={to} onChange={(e) => setTo(e.target.value)} placeholder="recipient@example.com" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
          <div><label className="text-xs font-medium text-muted-foreground block mb-1">Subject *</label>
            <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Enter email subject" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
        </div>
        <div><label className="text-xs font-medium text-muted-foreground block mb-1">HTML Body</label>
          <textarea rows={6} placeholder={"<html>\n  <body>\n    <p>Your message...</p>\n  </body>\n</html>"} value={htmlBody} onChange={(e) => setHtmlBody(e.target.value)} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary font-mono resize-none" /></div>
        <div><label className="text-xs font-medium text-muted-foreground block mb-1">Plain Text Body</label>
          <textarea rows={3} placeholder="Plain text version..." value={textBody} onChange={(e) => setTextBody(e.target.value)} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none" /></div>
        <div className="flex gap-3">
          <button onClick={sendEmail} disabled={sending} className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 disabled:opacity-60 transition-all shadow-md shadow-purple-900/40">
            {sending ? <RefreshCw size={14} className="animate-spin" /> : <Send size={14} />}
            {sending ? "Sending..." : "Send Email"}
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all"><Eye size={14} /> Preview</button>
        </div>
      </div>
    </div>
  );
}

// ─── Bulk Mails ───────────────────────────────────────────────────────────────

function BulkMailsSender() {
  const [campaigns, setCampaigns] = useState<{ id: number; name: string; status: string; recipients: number; sent: number }[]>([]);
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState("");
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><Send size={20} className="text-primary" /> Bulk Mails Sender</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Create and manage mass email campaigns</p></div>
        <button onClick={() => setShowNew(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all"><Plus size={14} /> New Bulk Mail</button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[{ label: "Total Bulk Mails", value: campaigns.length, icon: Send, color: "text-violet-400" }, { label: "Active Now", value: 0, icon: Activity, color: "text-emerald-400" }, { label: "Total Recipients", value: 0, icon: Users, color: "text-cyan-400" }, { label: "Emails Sent", value: 0, icon: Mail, color: "text-amber-400" }].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
            <Icon size={20} className={color} />
            <div><div className="text-xl font-bold text-foreground">{value}</div><div className="text-[11px] text-muted-foreground">{label}</div></div>
          </div>
        ))}
      </div>
      {campaigns.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-600 to-purple-700 flex items-center justify-center mb-4 shadow-xl shadow-purple-900/40"><Send size={28} className="text-white" /></div>
          <h3 className="text-base font-medium text-foreground mb-1">No bulk mails yet</h3>
          <p className="text-xs text-muted-foreground mb-5">Create your first bulk mail campaign and reach thousands of recipients instantly</p>
          <button onClick={() => setShowNew(true)} className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all shadow-md shadow-purple-900/40"><Plus size={14} /> Create Your First Bulk Mail</button>
        </div>
      ) : (
        <div className="space-y-3">{campaigns.map((c) => (
          <div key={c.id} className="bg-card rounded-xl border border-border px-5 py-4 flex items-center justify-between">
            <div><div className="text-sm font-medium text-foreground">{c.name}</div><div className="text-xs text-muted-foreground mt-0.5">{c.recipients} recipients · {c.sent} sent</div></div>
            <div className="flex items-center gap-3">
              <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">{c.status}</span>
              <button onClick={() => setCampaigns(campaigns.filter((x) => x.id !== c.id))} className="p-1.5 hover:bg-red-500/10 rounded-lg text-muted-foreground hover:text-red-400 transition-all"><Trash2 size={13} /></button>
            </div>
          </div>
        ))}</div>
      )}
      {showNew && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="text-base font-semibold text-foreground">New Bulk Mail</h2><button onClick={() => setShowNew(false)} className="text-muted-foreground hover:text-foreground"><X size={16} /></button></div>
            <div><label className="text-xs font-medium text-muted-foreground block mb-1">Campaign Name</label>
              <input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="e.g. Summer Promo 2025" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
            <div className="flex gap-2">
              <button onClick={() => setShowNew(false)} className="flex-1 py-2 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all">Cancel</button>
              <button onClick={() => { if (newName.trim()) { setCampaigns([...campaigns, { id: Date.now(), name: newName, status: "Draft", recipients: 0, sent: 0 }]); setNewName(""); setShowNew(false); } }} className="flex-1 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all">Create</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Recipients ───────────────────────────────────────────────────────────────

function Recipients() {
  const [emails, setEmails] = useState<string[]>([]);
  const [input, setInput] = useState("");
  const addEmails = () => {
    const n = input.split(/[\n,;]+/).map((e) => e.trim()).filter((e) => e.includes("@"));
    setEmails([...new Set([...emails, ...n])]);
    setInput("");
  };
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><Users size={20} className="text-primary" /> Recipients</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Manage your email recipient lists</p></div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all"><Upload size={14} /> Import</button>
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all"><Download size={14} /> Export</button>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        {[{ label: "Total", v: emails.length, c: "text-foreground" }, { label: "Verified", v: 0, c: "text-emerald-400" }, { label: "Bounced", v: 0, c: "text-red-400" }].map(({ label, v, c }) => (
          <div key={label} className="bg-card rounded-xl border border-border p-4 text-center">
            <div className={`text-2xl font-bold ${c}`}>{v}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
          </div>
        ))}
      </div>
      <div className="bg-card rounded-xl border border-border p-5 space-y-3">
        <h2 className="text-sm font-semibold text-foreground">Add Recipients</h2>
        <textarea rows={4} placeholder={"email1@example.com\nemail2@example.com"} value={input} onChange={(e) => setInput(e.target.value)} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none" />
        <button onClick={addEmails} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all"><Plus size={14} /> Add Emails</button>
      </div>
      {emails.length > 0 && (
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <span className="text-sm font-medium text-foreground">{emails.length} recipients</span>
            <button onClick={() => setEmails([])} className="text-xs text-red-400 hover:text-red-300">Clear all</button>
          </div>
          <div className="max-h-64 overflow-y-auto divide-y divide-border">
            {emails.map((email, i) => (
              <div key={i} className="flex items-center justify-between px-4 py-2">
                <span className="text-xs text-foreground">{email}</span>
                <button onClick={() => setEmails(emails.filter((_, j) => j !== i))} className="text-muted-foreground hover:text-red-400"><X size={12} /></button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Templates ────────────────────────────────────────────────────────────────

function Templates() {
  const [templates, setTemplates] = useState([
    { id: 1, name: "Welcome Email", subject: "Welcome to our platform!", category: "Onboarding" },
    { id: 2, name: "Password Reset", subject: "Reset your password", category: "Transactional" },
    { id: 3, name: "Newsletter", subject: "Monthly Newsletter - {{month}}", category: "Marketing" },
    { id: 4, name: "Promo Blast", subject: "Special Offer Just For You", category: "Promotional" },
  ]);
  const [showNew, setShowNew] = useState(false);
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><FileText size={20} className="text-primary" /> Email Templates</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Create and manage reusable email templates</p></div>
        <button onClick={() => setShowNew(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all"><Plus size={14} /> New Template</button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {templates.map((t) => (
          <div key={t.id} className="bg-card rounded-xl border border-border p-4 space-y-3 hover:border-primary/40 transition-colors">
            <div className="flex items-start justify-between">
              <div className="w-9 h-9 rounded-lg bg-violet-600/20 flex items-center justify-center"><FileText size={16} className="text-violet-400" /></div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground">{t.category}</span>
            </div>
            <div><div className="text-sm font-medium text-foreground">{t.name}</div><div className="text-xs text-muted-foreground mt-0.5 truncate">{t.subject}</div></div>
            <div className="flex gap-2 pt-1">
              <button className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg border border-border text-xs text-foreground hover:bg-muted transition-all"><Edit2 size={11} /> Edit</button>
              <button className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg border border-border text-xs text-foreground hover:bg-muted transition-all"><Copy size={11} /> Use</button>
              <button onClick={() => setTemplates(templates.filter((x) => x.id !== t.id))} className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-all"><Trash2 size={12} /></button>
            </div>
          </div>
        ))}
      </div>
      {showNew && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-lg p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="text-base font-semibold text-foreground">New Template</h2><button onClick={() => setShowNew(false)} className="text-muted-foreground hover:text-foreground"><X size={16} /></button></div>
            {[["Template Name", "e.g. Welcome Email"], ["Subject", "Email subject line"]].map(([l, p]) => (
              <div key={l}><label className="text-xs font-medium text-muted-foreground block mb-1">{l}</label>
                <input placeholder={p} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
            ))}
            <div><label className="text-xs font-medium text-muted-foreground block mb-1">HTML Body</label>
              <textarea rows={6} placeholder="<html>...</html>" className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary font-mono resize-none" /></div>
            <div className="flex gap-2">
              <button onClick={() => setShowNew(false)} className="flex-1 py-2 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all">Cancel</button>
              <button onClick={() => setShowNew(false)} className="flex-1 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all">Save Template</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Email Verifier ───────────────────────────────────────────────────────────

function EmailVerifier() {
  const [input, setInput] = useState("");
  const [results, setResults] = useState<{ email: string; status: "valid" | "invalid" }[]>([]);
  const [loading, setLoading] = useState(false);
  const verify = () => {
    const emails = input.split(/[\n,;]+/).map((e) => e.trim()).filter(Boolean);
    if (!emails.length) return;
    setLoading(true);
    setTimeout(() => {
      setResults(emails.map((email) => ({ email, status: email.includes("@") && email.includes(".") ? (Math.random() > 0.3 ? "valid" : "invalid") : "invalid" })));
      setLoading(false);
    }, 1200);
  };
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><ShieldCheck size={20} className="text-primary" /> Email Verifier</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Check email validity and deliverability</p></div>
      <div className="bg-card rounded-xl border border-border p-5 space-y-4">
        <h2 className="text-sm font-semibold text-foreground">Enter Emails to Verify</h2>
        <textarea rows={6} placeholder={"email1@example.com\nemail2@domain.com"} value={input} onChange={(e) => setInput(e.target.value)} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none" />
        <button onClick={verify} disabled={loading} className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 disabled:opacity-60 transition-all">
          {loading ? <RefreshCw size={14} className="animate-spin" /> : <ShieldCheck size={14} />}{loading ? "Verifying..." : "Verify Emails"}
        </button>
      </div>
      {results.length > 0 && (
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <span className="text-sm font-medium text-foreground">Results — {results.length} checked</span>
            <div className="flex gap-3 text-xs"><span className="text-emerald-400">{results.filter((r) => r.status === "valid").length} valid</span><span className="text-red-400">{results.filter((r) => r.status === "invalid").length} invalid</span></div>
          </div>
          <div className="max-h-72 overflow-y-auto divide-y divide-border">
            {results.map((r, i) => (
              <div key={i} className="flex items-center justify-between px-4 py-2.5">
                <span className="text-xs text-foreground">{r.email}</span>
                {r.status === "valid" ? <span className="flex items-center gap-1 text-xs text-emerald-400"><CheckCircle size={13} /> Valid</span> : <span className="flex items-center gap-1 text-xs text-red-400"><XCircle size={13} /> Invalid</span>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Logs ─────────────────────────────────────────────────────────────────────

function Logs() {
  const logs = Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    type: ["INFO", "ERROR", "SUCCESS", "WARNING"][i % 4],
    message: ["Email sent successfully to user@example.com", "SMTP connection failed: secure.emailsrvr.com", "Campaign started", "Rate limit reached for Rackspace 3"][i % 4],
    time: `${(23 - i).toString().padStart(2, "0")}:${(59 - i * 3).toString().padStart(2, "0")}:30`,
  }));
  const colors: Record<string, string> = { INFO: "text-cyan-400 bg-cyan-500/10", ERROR: "text-red-400 bg-red-500/10", SUCCESS: "text-emerald-400 bg-emerald-500/10", WARNING: "text-amber-400 bg-amber-500/10" };
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><ScrollText size={20} className="text-primary" /> Activity Logs</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Monitor all system activity and events</p></div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all"><Download size={14} /> Export</button>
          <button className="flex items-center gap-2 px-3 py-2 rounded-lg border border-border text-sm text-red-400 hover:bg-red-500/10 transition-all"><Trash2 size={14} /> Clear</button>
        </div>
      </div>
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center gap-3">
          <div className="relative flex-1"><Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" /><input placeholder="Search logs..." className="w-full bg-input-background border border-border rounded-lg pl-8 pr-3 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
          <select className="bg-input-background border border-border rounded-lg px-3 py-1.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary">
            {["All Types", "INFO", "SUCCESS", "ERROR", "WARNING"].map((t) => <option key={t}>{t}</option>)}
          </select>
        </div>
        <div className="divide-y divide-border">
          {logs.map((log) => (
            <div key={log.id} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${colors[log.type]}`}>{log.type}</span>
              <span className="text-xs text-foreground flex-1">{log.message}</span>
              <span className="text-[10px] text-muted-foreground shrink-0">{log.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Settings ─────────────────────────────────────────────────────────────────

function SettingsPage() {
  const { user } = useAuth();
  const [settings, setSettings] = useState({ sendDelay: "500", maxRetries: "3", trackOpens: true, trackClicks: true, unsubscribeLink: true, timezone: "UTC" });
  const [saved, setSaved] = useState(false);
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><Settings size={20} className="text-primary" /> Settings</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Configure your email sending preferences</p></div>
      {saved && <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-sm"><CheckCircle size={16} /> Settings saved successfully!</div>}

      {/* Profile */}
      <div className="bg-card rounded-xl border border-border p-5 space-y-4">
        <h2 className="text-sm font-semibold text-foreground">Account Profile</h2>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-400 to-purple-600 flex items-center justify-center text-white text-xl font-bold">
            {user?.name?.[0]?.toUpperCase()}
          </div>
          <div>
            <div className="text-sm font-medium text-foreground">{user?.name}</div>
            <div className="text-xs text-muted-foreground">{user?.email}</div>
            <span className={`text-[10px] mt-1 inline-block px-2 py-0.5 rounded-full font-medium ${user?.role === "admin" ? "bg-violet-500/20 text-violet-400" : "bg-muted text-muted-foreground"}`}>{user?.role}</span>
          </div>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border p-5 space-y-4">
        <h2 className="text-sm font-semibold text-foreground">Sending Configuration</h2>
        {[{ label: "Send Delay (ms)", key: "sendDelay" }, { label: "Max Retries", key: "maxRetries" }].map(({ label, key }) => (
          <div key={key} className="grid grid-cols-2 items-center gap-4">
            <label className="text-sm text-foreground">{label}</label>
            <input type="number" value={(settings as any)[key]} onChange={(e) => setSettings({ ...settings, [key]: e.target.value })} className="bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
          </div>
        ))}
        <div className="grid grid-cols-2 items-center gap-4">
          <label className="text-sm text-foreground">Timezone</label>
          <select value={settings.timezone} onChange={(e) => setSettings({ ...settings, timezone: e.target.value })} className="bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary">
            {["UTC", "US/Eastern", "US/Pacific", "Europe/London", "Asia/Karachi"].map((t) => <option key={t}>{t}</option>)}
          </select>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border p-5 space-y-4">
        <h2 className="text-sm font-semibold text-foreground">Tracking & Compliance</h2>
        {[{ label: "Track Email Opens", key: "trackOpens" }, { label: "Track Link Clicks", key: "trackClicks" }, { label: "Add Unsubscribe Link", key: "unsubscribeLink" }].map(({ label, key }) => (
          <div key={key} className="flex items-center justify-between">
            <span className="text-sm text-foreground">{label}</span>
            <button onClick={() => setSettings({ ...settings, [key]: !(settings as any)[key] })} className={`relative w-10 h-5 rounded-full transition-colors ${(settings as any)[key] ? "bg-primary" : "bg-muted"}`}>
              <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform shadow ${(settings as any)[key] ? "translate-x-5" : "translate-x-0.5"}`} />
            </button>
          </div>
        ))}
      </div>
      <button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 3000); }} className="px-5 py-2.5 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all shadow-md shadow-purple-900/40">Save Settings</button>
    </div>
  );
}

// ─── Admin: User Management ───────────────────────────────────────────────────

function UserManagement() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState([
    { id: "1", name: "Admin User", email: "admin@bosssender.com", role: "admin" as const, status: "active", joined: "2025-01-01" },
    { id: "2", name: "Demo User", email: "user@bosssender.com", role: "user" as const, status: "active", joined: "2025-03-15" },
    { id: "3", name: "John Smith", email: "john@example.com", role: "user" as const, status: "inactive", joined: "2025-05-20" },
  ]);
  const [showAdd, setShowAdd] = useState(false);
  const [newUser, setNewUser] = useState({ name: "", email: "", role: "user", password: "" });

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><Users size={20} className="text-primary" /> User Management</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Manage platform users and permissions</p></div>
        <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all"><UserPlus size={14} /> Add User</button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[{ label: "Total Users", val: users.length, color: "text-foreground" }, { label: "Active", val: users.filter((u) => u.status === "active").length, color: "text-emerald-400" }, { label: "Admins", val: users.filter((u) => u.role === "admin").length, color: "text-violet-400" }].map(({ label, val, color }) => (
          <div key={label} className="bg-card rounded-xl border border-border p-4 text-center">
            <div className={`text-2xl font-bold ${color}`}>{val}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
          </div>
        ))}
      </div>

      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center gap-2">
          <Search size={13} className="text-muted-foreground" />
          <input placeholder="Search users..." className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none" />
        </div>
        <div className="divide-y divide-border">
          {users.map((u) => (
            <div key={u.id} className="flex items-center gap-4 px-4 py-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-400 to-purple-600 flex items-center justify-center text-white text-xs font-bold shrink-0">
                {u.name[0]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-foreground">{u.name}</span>
                  {u.id === currentUser?.id && <span className="text-[10px] px-1.5 py-0.5 rounded bg-violet-500/20 text-violet-400">You</span>}
                </div>
                <div className="text-xs text-muted-foreground">{u.email}</div>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${u.role === "admin" ? "bg-violet-500/20 text-violet-400" : "bg-muted text-muted-foreground"}`}>{u.role}</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${u.status === "active" ? "bg-emerald-500/20 text-emerald-400" : "bg-muted text-muted-foreground"}`}>{u.status}</span>
              <div className="flex gap-1">
                <button className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-all"><Edit2 size={12} /></button>
                {u.id !== currentUser?.id && (
                  <button onClick={() => setUsers(users.filter((x) => x.id !== u.id))} className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-all"><Trash2 size={12} /></button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {showAdd && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl w-full max-w-sm p-6 space-y-4">
            <div className="flex items-center justify-between"><h2 className="text-base font-semibold text-foreground">Add New User</h2><button onClick={() => setShowAdd(false)} className="text-muted-foreground hover:text-foreground"><X size={16} /></button></div>
            {[["Full Name", "name", "text"], ["Email", "email", "email"], ["Password", "password", "password"]].map(([l, k, t]) => (
              <div key={k}><label className="text-xs font-medium text-muted-foreground block mb-1">{l}</label>
                <input type={t} value={(newUser as any)[k]} onChange={(e) => setNewUser({ ...newUser, [k]: e.target.value })} placeholder={l as string} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
            ))}
            <div><label className="text-xs font-medium text-muted-foreground block mb-1">Role</label>
              <select value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value })} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary">
                <option value="user">User</option><option value="admin">Admin</option>
              </select></div>
            <div className="flex gap-2">
              <button onClick={() => setShowAdd(false)} className="flex-1 py-2 rounded-lg border border-border text-sm text-foreground hover:bg-muted transition-all">Cancel</button>
              <button onClick={() => { if (newUser.name && newUser.email) { setUsers([...users, { id: Date.now().toString(), name: newUser.name, email: newUser.email, role: newUser.role as any, status: "active", joined: new Date().toISOString().split("T")[0] }]); setShowAdd(false); setNewUser({ name: "", email: "", role: "user", password: "" }); } }} className="flex-1 py-2 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all">Add User</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Admin: Backup & Restore ──────────────────────────────────────────────────

function BackupRestore() {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><HardDrive size={20} className="text-primary" /> Backup & Restore</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Export and import your configuration data</p></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {[{ label: "Export Backup", sub: "Download a complete backup of your SMTP accounts, templates, and settings.", icon: Download, color: "bg-emerald-500/20 text-emerald-400", btn: "bg-emerald-600 hover:bg-emerald-500", btnLabel: "Download Backup" },
          { label: "Restore Backup", sub: "Upload a previously exported backup file to restore your configuration.", icon: Upload, color: "bg-blue-500/20 text-blue-400", btn: "bg-blue-600 hover:bg-blue-500", btnLabel: "Upload Backup" }].map(({ label, sub, icon: Icon, color, btn, btnLabel }) => (
          <div key={label} className="bg-card rounded-xl border border-border p-5 space-y-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}><Icon size={18} /></div>
            <h2 className="text-sm font-semibold text-foreground">{label}</h2>
            <p className="text-xs text-muted-foreground">{sub}</p>
            <button className={`flex items-center gap-2 px-4 py-2 rounded-lg ${btn} text-white text-sm font-medium transition-all`}><Icon size={14} /> {btnLabel}</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminSettings() {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><Shield size={20} className="text-primary" /> Admin Settings</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Advanced system configuration</p></div>
      <div className="bg-card rounded-xl border border-border p-5 space-y-4">
        {[{ label: "Max Users", placeholder: "10" }, { label: "API Key", placeholder: "sk-..." }, { label: "Webhook URL", placeholder: "https://your-site.com/webhook" }, { label: "Rate Limit (global/min)", placeholder: "1000" }].map(({ label, placeholder }) => (
          <div key={label}><label className="text-xs font-medium text-muted-foreground block mb-1">{label}</label>
            <input placeholder={placeholder} className="w-full bg-input-background border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" /></div>
        ))}
        <button className="px-5 py-2.5 rounded-lg bg-primary text-white text-sm font-medium hover:bg-violet-600 transition-all">Save Admin Settings</button>
      </div>
    </div>
  );
}

function ResourceSharing() {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div><h1 className="text-xl font-semibold text-foreground flex items-center gap-2"><Share2 size={20} className="text-primary" /> Resource Sharing</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Share SMTP accounts and resources with sub-users</p></div>
      <div className="bg-card rounded-xl border border-border p-5 space-y-4">
        <h2 className="text-sm font-semibold text-foreground">Share SMTP Accounts</h2>
        {["Rackspace 1", "Rackspace 2", "Rackspace 3"].map((name) => (
          <div key={name} className="flex items-center justify-between py-2 border-b border-border last:border-0">
            <div className="flex items-center gap-2"><Server size={14} className="text-muted-foreground" /><span className="text-sm text-foreground">{name}</span></div>
            <button className="text-xs px-3 py-1 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition-all font-medium">Share</button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main App Shell ───────────────────────────────────────────────────────────

function AppShell() {
  const [page, setPage] = useState<Page>("dashboard");
  const renderPage = () => {
    switch (page) {
      case "dashboard": return <Dashboard setPage={setPage} />;
      case "smtp": return <SmtpAccounts />;
      case "proxies": return <Proxies />;
      case "single-mail": return <SingleMail />;
      case "bulk-mails": return <BulkMailsSender />;
      case "recipients": return <Recipients />;
      case "templates": return <Templates />;
      case "email-verifier": return <EmailVerifier />;
      case "logs": return <Logs />;
      case "settings": return <SettingsPage />;
      case "admin-users": return <UserManagement />;
      case "backup": return <BackupRestore />;
      case "admin-settings": return <AdminSettings />;
      case "resource-sharing": return <ResourceSharing />;
      default: return <Dashboard setPage={setPage} />;
    }
  };
  return (
    <div className="flex h-screen w-full bg-background overflow-hidden" style={{ fontFamily: "Inter, sans-serif" }}>
      <Sidebar page={page} setPage={setPage} />
      {renderPage()}
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <AuthProvider>
      <AuthGate />
    </AuthProvider>
  );
}

function AuthGate() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center" style={{ fontFamily: "Inter, sans-serif" }}>
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-700 flex items-center justify-center animate-pulse">
            <Send size={20} className="text-white" />
          </div>
          <p className="text-sm text-muted-foreground">Loading Boss Sender...</p>
        </div>
      </div>
    );
  }

  return user ? <AppShell /> : <AuthPage />;
}
