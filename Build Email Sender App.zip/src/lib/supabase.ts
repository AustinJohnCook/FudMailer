import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://tcvpkupkasvptdivfwmo.supabase.co";
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRjdnBrdXBrYXN2cHRkaXZmd21vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM2NTcxNTcsImV4cCI6MjA5OTIzMzE1N30.rhU-0JganIbQDPvFGuICtLv4ADAhME3I48cOG03j_P8";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
export const isSupabaseConfigured = true;
