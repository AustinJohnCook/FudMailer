import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { action, payload } = await req.json();

    if (action === "send-email") {
      const { smtpHost, smtpPort, smtpUser, smtpPass, fromEmail, fromName, to, subject, html, text } = payload;

      // Use Deno's built-in fetch to call an SMTP-over-HTTP relay,
      // or use nodemailer via npm
      const nodemailer = await import("npm:nodemailer@6.9.9");

      const transporter = nodemailer.default.createTransporter({
        host: smtpHost,
        port: Number(smtpPort) || 587,
        secure: Number(smtpPort) === 465,
        auth: {
          user: smtpUser,
          pass: smtpPass,
        },
        tls: { rejectUnauthorized: false },
      });

      const info = await transporter.sendMail({
        from: fromName ? `"${fromName}" <${fromEmail}>` : fromEmail,
        to: Array.isArray(to) ? to.join(", ") : to,
        subject,
        html: html || undefined,
        text: text || undefined,
      });

      return new Response(
        JSON.stringify({ success: true, messageId: info.messageId }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (action === "verify-smtp") {
      const { smtpHost, smtpPort, smtpUser, smtpPass } = payload;
      const nodemailer = await import("npm:nodemailer@6.9.9");

      const transporter = nodemailer.default.createTransporter({
        host: smtpHost,
        port: Number(smtpPort) || 587,
        secure: Number(smtpPort) === 465,
        auth: { user: smtpUser, pass: smtpPass },
        tls: { rejectUnauthorized: false },
      });

      await transporter.verify();
      return new Response(
        JSON.stringify({ success: true, message: "SMTP connection verified" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ error: "Unknown action" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err: any) {
    return new Response(
      JSON.stringify({ success: false, error: err.message || "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
